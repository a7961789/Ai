
import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="戰神賽特 AI 分析器", layout="centered")

st.markdown("# ⚔️ 戰神賽特 AI 分析器")
st.write("模擬老虎機轉輪、熱/冷區分析與下注策略建議")

# 輸入設定區
col1, col2 = st.columns(2)
with col1:
    start_money = st.number_input("起始金額", value=10000, step=100)
    bet_base = st.number_input("每輪基礎下注", value=50, step=10)
    spins = st.number_input("模擬輪數", min_value=1, value=300, step=10)
with col2:
    rtp_range = st.slider("RTP 區間（%）", 80, 100, (92, 98))
    strategy = st.selectbox("下注策略", ["固定注", "遞增注", "智能策略"])

rtp_min = rtp_range[0] / 100
rtp_max = rtp_range[1] / 100

if st.button("▶️ 開始模擬"):
    money = start_money
    multipliers = []
    bets = []
    bet = bet_base
    rtp = np.random.uniform(rtp_min, rtp_max)

    lose_streak = 0
    for i in range(spins):
        if money < bet:
            break

        if strategy == "遞增注":
            bet = bet_base * (1 + lose_streak)
        elif strategy == "智能策略":
            if lose_streak >= 6:
                bet = max(int(bet_base * 0.5), 1)
            elif lose_streak == 0:
                bet = bet_base * 2
            else:
                bet = bet_base

        win_chance = np.random.rand()
        if win_chance < rtp:
            multiplier = np.random.choice([0.5, 1, 2, 3, 5, 10])
        else:
            multiplier = 0

        win_amount = bet * multiplier
        money += win_amount - bet
        multipliers.append(multiplier)
        bets.append(bet)

        if multiplier == 0:
            lose_streak += 1
        else:
            lose_streak = 0

    df = pd.DataFrame({
        "輪數": list(range(1, len(multipliers) + 1)),
        "倍率": multipliers,
        "下注金額": bets,
    })
    df["獲利"] = (df["倍率"] * df["下注金額"]) - df["下注金額"]
    df["累計獲利"] = df["獲利"].cumsum()

    actual_rtp = df["倍率"].mean()
    st.subheader("📊 結果摘要")
    st.write(f"- 實際 RTP：{actual_rtp * 100:.2f}%")
    st.write(f"- 最終金額：{money}")
    st.write(f"- 總盈虧：{money - start_money}")

    st.subheader("📈 倍率走勢圖")
    fig, ax = plt.subplots(figsize=(6, 3))
    ax.plot(df["輪數"], df["倍率"], marker='o', markersize=3, linewidth=1)
    ax.set_xlabel("輪數")
    ax.set_ylabel("倍率")
    ax.grid(True)
    st.pyplot(fig)
